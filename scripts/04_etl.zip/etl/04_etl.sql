-- =====================================================================
--  CDD-IN | Tarea 4: Proceso ETL de las planillas de sucursales
--  Ejecutar con psql, conectada a la base cddin, desde la carpeta
--  donde están las planillas:
--      \cd 'C:/ruta/a/la/carpeta/etl'
--      \i 04_etl.sql
-- ---------------------------------------------------------------------
--  Resultado:
--    stg.ventas_integradas  -> ventas de la BD + planillas limpias (listas para el DW)
--    stg.rechazos           -> líneas descartadas y el motivo
--    stg.log_etl            -> resumen de cada paso
--  Regla general: la BD gobernada (fact_ventas) tiene prioridad sobre
--  cualquier planilla.
-- =====================================================================
\set ON_ERROR_STOP on

DROP SCHEMA IF EXISTS stg CASCADE;
CREATE SCHEMA stg;
CREATE TABLE stg.log_etl (paso TEXT, detalle TEXT, filas INTEGER);

-- =====================================================================
-- 1) EXTRACCIÓN: se cargan las planillas "tal cual", todo como texto.
--    nro_linea guarda el orden original de cada archivo.
-- =====================================================================
CREATE TABLE stg.raw_csv (
    nro_linea INTEGER GENERATED ALWAYS AS IDENTITY,
    pedido TEXT, producto TEXT, fecha TEXT, empleado TEXT, cantidad TEXT,
    ingresos TEXT, costo TEXT, descuento TEXT, cliente TEXT);
CREATE TABLE stg.raw_txt (LIKE stg.raw_csv INCLUDING ALL);
CREATE TABLE stg.raw_xls (
    nro_linea INTEGER GENERATED ALWAYS AS IDENTITY,
    pedido TEXT, producto TEXT, fecha TEXT, empleado TEXT, sucursal TEXT, cantidad TEXT,
    ingresos TEXT, costo TEXT, descuento TEXT, cliente TEXT, tipo_pago TEXT);

\copy stg.raw_csv (pedido,producto,fecha,empleado,cantidad,ingresos,costo,descuento,cliente) FROM 'planilla sucursal - cvs.csv' WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'LATIN1')
-- El TXT se lee línea completa, porque hay filas donde la tabulación fue
-- reemplazada por espacios. Se normaliza y luego se separa en columnas.
CREATE TABLE stg.raw_txt_lineas (nro_linea INTEGER GENERATED ALWAYS AS IDENTITY, linea TEXT);
\copy stg.raw_txt_lineas (linea) FROM 'planilla tienda sucursal 33.txt' WITH (FORMAT csv, HEADER true, DELIMITER E'\x01', QUOTE E'\x02', ENCODING 'LATIN1')
INSERT INTO stg.raw_txt (pedido,producto,fecha,empleado,cantidad,ingresos,costo,descuento,cliente)
SELECT f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8],f[9]
FROM (SELECT nro_linea,
             string_to_array(regexp_replace(rtrim(linea, E'\r'), '([^\t ]) {2,}([^\t ])', E'\\1\t\\2', 'g'), E'\t') AS f
      FROM stg.raw_txt_lineas ORDER BY nro_linea) x;
\copy stg.raw_xls (pedido,producto,fecha,empleado,sucursal,cantidad,ingresos,costo,descuento,cliente,tipo_pago) FROM 'planilla datos tienda local.csv' WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8')

INSERT INTO stg.log_etl
SELECT '1. Extracción', 'CSV sucursal', COUNT(*) FROM stg.raw_csv UNION ALL
SELECT '1. Extracción', 'TXT sucursal 33', COUNT(*) FROM stg.raw_txt UNION ALL
SELECT '1. Extracción', 'Excel tienda local', COUNT(*) FROM stg.raw_xls;

-- =====================================================================
-- 2) FUNCIONES DE LIMPIEZA (reutilizables para cualquier planilla)
-- =====================================================================

-- Texto -> número, aceptando coma o punto decimal. Inválido -> NULL
CREATE FUNCTION stg.a_numero(t TEXT) RETURNS NUMERIC LANGUAGE sql IMMUTABLE AS $$
    SELECT CASE WHEN trim(t) ~ '^-?[0-9]+([.,][0-9]+)?$'
                THEN replace(trim(t), ',', '.')::NUMERIC END $$;

-- Texto -> fecha. Acepta '28-dic-16' y '2016-12-29'.
-- Formatos ambiguos o texto libre ('lunes', 'enero', '28enero16') -> NULL
CREATE FUNCTION stg.a_fecha(t TEXT) RETURNS DATE LANGUAGE sql IMMUTABLE AS $$
    SELECT CASE
      WHEN trim(t) ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN trim(t)::DATE
      WHEN lower(trim(t)) ~ '^[0-9]{1,2}-(ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)-[0-9]{2}$' THEN
        make_date(2000 + split_part(trim(t),'-',3)::INT,
                  array_position(ARRAY['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'],
                                 lower(split_part(trim(t),'-',2))),
                  split_part(trim(t),'-',1)::INT)
    END $$;

-- Número de pedido válido = 6 dígitos que empiezan con 16.
-- En el TXT algunos traen un dígito de más adelante (3161562 -> 161562).
CREATE FUNCTION stg.a_pedido(t TEXT) RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT CASE
      WHEN trim(t) ~ '^16[0-9]{4}$'      THEN trim(t)::INT
      WHEN trim(t) ~ '^[0-9]16[0-9]{4}$' THEN right(trim(t),6)::INT
    END $$;

-- Extrae solo los dígitos ('Empleado 16' -> 16, 'Sucursal 2' -> 2, 's2' -> 2)
CREATE FUNCTION stg.a_entero(t TEXT) RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT NULLIF(regexp_replace(coalesce(t,''), '[^0-9]', '', 'g'), '')::INT $$;

-- Estandariza el tipo de pago escrito a mano
CREATE FUNCTION stg.a_tipo_pago(t TEXT) RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT CASE lower(trim(coalesce(t,'')))
      WHEN 'contado' THEN 'Efectivo' WHEN 'efectivo' THEN 'Efectivo' WHEN 'c' THEN 'Efectivo'
      WHEN 'cta cte' THEN 'Cuenta corriente' WHEN 'cc' THEN 'Cuenta corriente'
      WHEN 'tarjeta' THEN 'Tarjeta (sin especificar)' WHEN 'tt' THEN 'Tarjeta (sin especificar)'
    END $$;

-- =====================================================================
-- 3) TRANSFORMACIÓN A: conciliar CSV + TXT
--    Son EL MISMO informe enviado dos veces en distinto formato
--    (misma línea en la misma posición). Se fusionan en un único
--    registro, tomando de cada campo el valor válido.
-- =====================================================================
CREATE TABLE stg.lineas AS
WITH par AS (
  SELECT c.nro_linea,
         stg.a_pedido(c.pedido) AS ped_c, stg.a_pedido(t.pedido) AS ped_t,
         stg.a_entero(c.producto) AS prod_c, stg.a_entero(t.producto) AS prod_t,
         stg.a_fecha(c.fecha) AS fec_c, stg.a_fecha(t.fecha) AS fec_t,
         stg.a_entero(c.empleado) AS emp_c, stg.a_entero(t.empleado) AS emp_t,
         stg.a_numero(c.cantidad) AS cnt_c, stg.a_numero(t.cantidad) AS cnt_t,
         coalesce(stg.a_numero(c.ingresos), stg.a_numero(t.ingresos)) AS ingresos,
         coalesce(stg.a_numero(c.costo), stg.a_numero(t.costo)) AS costo,
         coalesce(stg.a_numero(c.descuento), stg.a_numero(t.descuento), 0) AS descuento,
         stg.a_entero(c.cliente) AS cli_c, stg.a_entero(t.cliente) AS cli_t
  FROM stg.raw_csv c JOIN stg.raw_txt t USING (nro_linea)
)
SELECT 'CSV+TXT'::TEXT AS fuente, nro_linea,
       coalesce(ped_c, ped_t) AS pedido_id,
       (SELECT producto_id FROM lu_producto WHERE producto_id IN (prod_c, prod_t) LIMIT 1) AS producto_id,
       coalesce(fec_c, fec_t) AS fecha_pedido,
       (SELECT empleado_id FROM lu_empleado WHERE empleado_id IN (emp_c, emp_t) LIMIT 1) AS empleado_id,
       (SELECT cliente_id FROM lu_cliente WHERE cliente_id IN (cli_c, cli_t) LIMIT 1) AS cliente_id,
       NULL::TEXT AS tipo_pago,           -- estas planillas no informan forma de pago
       ARRAY[cnt_c, cnt_t] AS cantidades_informadas,
       ingresos, costo, descuento
FROM par;

-- TRANSFORMACIÓN B: Excel de la tienda local
INSERT INTO stg.lineas
SELECT 'EXCEL', nro_linea,
       CASE WHEN trim(pedido) ~ '^16[0-9]{4}$' THEN trim(pedido)::INT END,
       (SELECT producto_id FROM lu_producto WHERE producto_id = stg.a_entero(x.producto)),
       stg.a_fecha(fecha),
       (SELECT empleado_id FROM lu_empleado WHERE empleado_id = stg.a_entero(x.empleado)),  -- '233' no existe -> NULL
       (SELECT cliente_id FROM lu_cliente WHERE cliente_id = stg.a_entero(x.cliente)),
       stg.a_tipo_pago(tipo_pago),
       ARRAY[stg.a_numero(cantidad)],
       stg.a_numero(ingresos), stg.a_numero(costo), coalesce(stg.a_numero(descuento), 0)
FROM stg.raw_xls x;
-- La columna "Sucursal" del Excel se descarta (dato redundante e inconsistente):
-- la sucursal se obtiene del maestro LU_EMPLEADO.

ALTER TABLE stg.lineas ADD COLUMN cnt_unidades INTEGER, ADD COLUMN observacion TEXT DEFAULT '';

-- C) Producto faltante (Excel): se busca en el maestro el ÚNICO producto
--    cuyo precio y costo unitario coinciden con los montos de la línea.
UPDATE stg.lineas l SET producto_id = m.producto_id, observacion = observacion || 'producto inferido por precio/costo; '
FROM (SELECT l2.fuente, l2.nro_linea, min(p.producto_id) AS producto_id
      FROM stg.lineas l2 JOIN lu_producto p
        ON p.mnt_precio_unitario = l2.ingresos AND round(p.mnt_costo_unitario, 2) = round(l2.costo, 2)
      WHERE l2.producto_id IS NULL
      GROUP BY l2.fuente, l2.nro_linea HAVING COUNT(*) = 1) m
WHERE l.fuente = m.fuente AND l.nro_linea = m.nro_linea;

-- D) Cantidad: se valida contra el maestro (ingresos = precio unitario x cantidad).
--    Si la informada no cierra o falta, se recalcula.
UPDATE stg.lineas l SET
  cnt_unidades = coalesce(
      (SELECT c::INT FROM unnest(l.cantidades_informadas) c
        WHERE c > 0 AND abs(c * p.mnt_precio_unitario - l.ingresos) < 0.01 LIMIT 1),
      greatest(round(l.ingresos / NULLIF(p.mnt_precio_unitario, 0)), 1)::INT),
  observacion = observacion || CASE WHEN NOT EXISTS (
      SELECT 1 FROM unnest(l.cantidades_informadas) c
       WHERE c > 0 AND abs(c * p.mnt_precio_unitario - l.ingresos) < 0.01)
      THEN 'cantidad recalculada; ' ELSE '' END
FROM lu_producto p WHERE p.producto_id = l.producto_id;

-- E) Datos de "cabecera" del ticket (fecha, empleado, cliente, pago).
--    Un ticket tiene UNA fecha, UN empleado y UN cliente. Si el ticket ya
--    existe en la BD, manda la BD; si no, se toma el valor más repetido
--    entre las líneas válidas de ese mismo ticket en las planillas.
CREATE TABLE stg.cabecera AS
WITH bd AS (
  SELECT pedido_id, min(fecha_pedido) AS fecha_pedido,
         mode() WITHIN GROUP (ORDER BY empleado_id)  AS empleado_id,
         mode() WITHIN GROUP (ORDER BY cliente_id)   AS cliente_id,
         mode() WITHIN GROUP (ORDER BY tipo_pago_id) AS tipo_pago_id,
         mode() WITHIN GROUP (ORDER BY promocion_id) AS promocion_id
  FROM fact_ventas WHERE pedido_id IN (SELECT pedido_id FROM stg.lineas)
  GROUP BY pedido_id),
pl AS (
  SELECT pedido_id,
         mode() WITHIN GROUP (ORDER BY fecha_pedido) AS fecha_pedido,
         mode() WITHIN GROUP (ORDER BY empleado_id)  AS empleado_id,
         mode() WITHIN GROUP (ORDER BY cliente_id)   AS cliente_id,
         mode() WITHIN GROUP (ORDER BY tipo_pago)    AS tipo_pago
  FROM stg.lineas WHERE pedido_id IS NOT NULL GROUP BY pedido_id)
SELECT pl.pedido_id,
       (bd.pedido_id IS NOT NULL)                          AS existe_en_bd,
       coalesce(bd.fecha_pedido, pl.fecha_pedido)          AS fecha_pedido,
       coalesce(bd.empleado_id, pl.empleado_id)            AS empleado_id,
       coalesce(bd.cliente_id, pl.cliente_id)              AS cliente_id,
       coalesce(tp.tipo_pago_desc, pl.tipo_pago, 'No informado') AS tipo_pago,
       coalesce(bd.promocion_id, -1)                       AS promocion_id   -- -1 = No informada
FROM pl LEFT JOIN bd USING (pedido_id)
LEFT JOIN lu_tipo_pago tp ON tp.tipo_pago_id = bd.tipo_pago_id;

-- =====================================================================
-- 4) RECHAZOS: lo que no se puede reparar no entra al DW (queda registrado)
-- =====================================================================
CREATE TABLE stg.rechazos AS
SELECT l.*, CASE
    WHEN l.pedido_id IS NULL   THEN 'Número de pedido inválido, no se puede reconstruir'
    WHEN l.producto_id IS NULL THEN 'Producto faltante, no se pudo inferir'
    WHEN EXISTS (SELECT 1 FROM fact_ventas v WHERE v.pedido_id = l.pedido_id AND v.producto_id = l.producto_id)
                               THEN 'Duplicado: la línea ya existe en la BD (prevalece la BD)'
    WHEN c.fecha_pedido IS NULL OR c.empleado_id IS NULL OR c.cliente_id IS NULL
                               THEN 'Ticket sin fecha, empleado o cliente válidos'
  END AS motivo
FROM stg.lineas l LEFT JOIN stg.cabecera c USING (pedido_id);
DELETE FROM stg.rechazos WHERE motivo IS NULL;

-- Duplicados entre planillas (misma línea informada por dos fuentes): queda la primera
INSERT INTO stg.rechazos
SELECT l.*, 'Duplicado entre planillas' FROM stg.lineas l
WHERE (l.fuente, l.nro_linea) IN (
  SELECT fuente, nro_linea FROM (
    SELECT fuente, nro_linea,
           row_number() OVER (PARTITION BY pedido_id, producto_id ORDER BY fuente, nro_linea) AS rn
    FROM stg.lineas x
    WHERE NOT EXISTS (SELECT 1 FROM stg.rechazos r WHERE r.fuente = x.fuente AND r.nro_linea = x.nro_linea)
  ) z WHERE rn > 1);

-- =====================================================================
-- 5) RESULTADO: ventas integradas (BD + planillas limpias)
-- =====================================================================
CREATE TABLE stg.ventas_integradas AS
SELECT 'BD'::TEXT AS fuente, v.pedido_id, v.producto_id, v.fecha_pedido, v.empleado_id,
       v.cliente_id, v.promocion_id, tp.tipo_pago_desc AS tipo_pago,
       v.cnt_unidades_vendidas, v.mnt_ingresos, v.mnt_costo, v.mnt_descuento
FROM fact_ventas v JOIN lu_tipo_pago tp USING (tipo_pago_id)
UNION ALL
SELECT l.fuente, l.pedido_id, l.producto_id, c.fecha_pedido, c.empleado_id,
       c.cliente_id, c.promocion_id, c.tipo_pago,
       l.cnt_unidades, l.ingresos, l.costo, l.descuento
FROM stg.lineas l JOIN stg.cabecera c USING (pedido_id)
WHERE NOT EXISTS (SELECT 1 FROM stg.rechazos r WHERE r.fuente = l.fuente AND r.nro_linea = l.nro_linea);

INSERT INTO stg.log_etl
SELECT '2. Transformación', 'Líneas tras fusionar CSV+TXT', COUNT(*) FROM stg.lineas WHERE fuente = 'CSV+TXT' UNION ALL
SELECT '2. Transformación', 'Productos inferidos por precio/costo', COUNT(*) FROM stg.lineas WHERE observacion LIKE '%producto inferido%' UNION ALL
SELECT '2. Transformación', 'Cantidades recalculadas', COUNT(*) FROM stg.lineas WHERE observacion LIKE '%cantidad recalculada%' UNION ALL
SELECT '3. Rechazos', motivo, COUNT(*) FROM stg.rechazos GROUP BY motivo UNION ALL
SELECT '4. Resultado', 'Líneas de planillas incorporadas', COUNT(*) FROM stg.ventas_integradas WHERE fuente <> 'BD' UNION ALL
SELECT '4. Resultado', 'Total ventas integradas (BD + planillas)', COUNT(*) FROM stg.ventas_integradas;

SELECT * FROM stg.log_etl;
